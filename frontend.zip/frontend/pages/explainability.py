"""Page 3 - Explainability"""

import streamlit as st
import pandas as pd
import plotly.express as px
from components.api import get_explanation, with_spinner
from components.data import find_borrower, build_analysis_payload


def _get_top_features(loan_id: str, row: dict):
    """
    Reuses the /analyze result from Borrower Profile if it's for the same
    loan_id (saves an API call); otherwise calls /explain directly.
    """
    cached = st.session_state.get("analysis_data")
    if cached and st.session_state.get("customer_id") == loan_id:
        return cached.get("top_features"), None

    payload = build_analysis_payload(row)
    data = with_spinner("Fetching SHAP explanation...", get_explanation, payload)
    if data is None:
        return None, "fetch_failed"
    return data.get("top_features"), None


def render():
    st.title("🔍 Explainability")
    st.caption("SHAP-based feature importance and risk drivers")

    loan_id = st.text_input(
        "Loan ID", value=st.session_state.get("customer_id", ""), key="explain_loan_id"
    )

    if not loan_id:
        st.info("Enter a Loan ID to see what's driving their risk score.")
        return

    row = find_borrower(loan_id)
    if row is None:
        st.error(f"No borrower found with Loan ID '{loan_id}'.")
        return

    if st.button("Explain risk", type="primary"):
        top_features, err = _get_top_features(loan_id, row)
        st.session_state["explain_features"] = top_features

    features = st.session_state.get("explain_features")
    if not features:
        return

    # top_features comes back as [[feature, value], ...] pairs, not dicts
    df = pd.DataFrame(features, columns=["feature", "impact"])
    df["impact"] = pd.to_numeric(df["impact"], errors="coerce")
    df = df.dropna(subset=["impact"]).sort_values("impact", key=abs, ascending=True)

    if df.empty:
        st.warning("No feature importance data returned for this borrower.")
        return

    st.subheader("Top Risk Drivers")
    fig = px.bar(
        df,
        x="impact",
        y="feature",
        orientation="h",
        color="impact",
        color_continuous_scale=["#2ecc71", "#f39c12", "#e74c3c"],
    )
    fig.update_layout(
        margin=dict(t=10, b=10, l=10, r=10),
        coloraxis_showscale=False,
        yaxis_title="",
        xaxis_title="Impact on risk score",
    )
    st.plotly_chart(fig, use_container_width=True)

    with st.expander("Raw feature values"):
        st.dataframe(df.sort_values("impact", ascending=False), use_container_width=True)
