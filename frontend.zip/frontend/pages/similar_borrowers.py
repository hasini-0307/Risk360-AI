"""Page 4 - Similar Borrowers"""

import streamlit as st
import pandas as pd
from components.api import get_similar_borrowers, with_spinner
from components.data import find_borrower, build_analysis_payload, lookup_similar_borrower_details


def _get_similar(loan_id: str, row: dict):
    cached = st.session_state.get("analysis_data")
    if cached and st.session_state.get("customer_id") == loan_id:
        return cached.get("similar_borrowers")

    payload = build_analysis_payload(row)
    data = with_spinner("Retrieving similar borrowers...", get_similar_borrowers, payload)
    if data is None:
        return None
    return data.get("similar_borrowers")


def render():
    st.title("👥 Similar Borrowers")
    st.caption("Borrowers with a comparable profile (nearest-neighbor on branch notes / call summaries) and how their loans played out")

    loan_id = st.text_input(
        "Loan ID", value=st.session_state.get("customer_id", ""), key="similar_loan_id"
    )

    if not loan_id:
        st.info("Enter a Loan ID to find similar borrowers.")
        return

    row = find_borrower(loan_id)
    if row is None:
        st.error(f"No borrower found with Loan ID '{loan_id}'.")
        return

    if st.button("Find similar borrowers", type="primary"):
        st.session_state["similar_results"] = _get_similar(loan_id, row)

    results = st.session_state.get("similar_results")
    if not results:
        return

    # Backend only returns {LoanID, Distance} — enrich with the actual
    # outcome and branch notes from the local dataset for display.
    enriched = []
    for item in results:
        lid = item.get("LoanID")
        details = lookup_similar_borrower_details(lid)
        enriched.append(
            {
                "Loan ID": lid,
                "Similarity Distance": item.get("Distance"),
                "Outcome": details["outcome"],
                "Branch Notes": details["reason"],
            }
        )

    df = pd.DataFrame(enriched)

    search = st.text_input("Filter by Loan ID or outcome", key="similar_search")
    if search:
        mask = df.astype(str).apply(lambda col: col.str.contains(search, case=False, na=False))
        df = df[mask.any(axis=1)]

    for _, r in df.iterrows():
        with st.container(border=True):
            cols = st.columns([1, 1, 2])
            cols[0].markdown(f"**{r['Loan ID']}**")
            cols[1].markdown(f"Outcome: **{r['Outcome']}** (distance {r['Similarity Distance']})")
            cols[2].markdown(f"Notes: {r['Branch Notes']}")
