"""Page 1 - Executive Dashboard"""

import streamlit as st
import pandas as pd
import plotly.express as px
from components.styles import kpi_card
from components.config import RISK_COLORS


@st.cache_data
def load_portfolio_data():
    """
    Loads the portfolio-level dataset used for the executive KPIs and
    charts. Replace this with a real backend call (e.g. a future
    /portfolio endpoint) once Person 2 exposes one; for now this reads
    the shared dataset used by the ML pipeline so the dashboard has
    real numbers to show.
    """
    try:
        df = pd.read_csv("data/Loan_default_multimodal.csv")
    except FileNotFoundError:
        return None
    return df


def _risk_level_from_default_flag(df: pd.DataFrame) -> pd.Series:
    # Placeholder bucketing until /predict-derived risk levels are
    # available for the full portfolio. Swap for real risk_level values
    # returned by the backend when a bulk-scoring endpoint exists.
    bins = [-1, 0.33, 0.66, 1.01]
    labels = ["LOW", "MEDIUM", "HIGH"]
    if "DTIRatio" in df.columns:
        return pd.cut(df["DTIRatio"], bins=bins, labels=labels)
    return pd.Series(["LOW"] * len(df))


def render():
    st.title("📊 Executive Dashboard")
    st.caption("Portfolio-wide risk overview")

    df = load_portfolio_data()

    if df is None:
        st.warning(
            "Portfolio dataset not found at `data/Loan_default_multimodal.csv`. "
            "Showing placeholder numbers — drop the CSV in place or wire up "
            "a bulk /portfolio endpoint to populate this live."
        )
        total, high, medium, low, alerts = 12500, 1875, 4200, 6425, 37
    else:
        with st.expander("Filters", expanded=False):
            f1, f2, f3 = st.columns(3)
            loan_types = sorted(df["LoanPurpose"].dropna().unique()) if "LoanPurpose" in df.columns else []
            selected_types = f1.multiselect("Loan type", loan_types, default=loan_types)

            education = sorted(df["Education"].dropna().unique()) if "Education" in df.columns else []
            selected_education = f2.multiselect("Education", education, default=education)

            employment = sorted(df["EmploymentType"].dropna().unique()) if "EmploymentType" in df.columns else []
            selected_employment = f3.multiselect("Employment type", employment, default=employment)

        if selected_types:
            df = df[df["LoanPurpose"].isin(selected_types)]
        if selected_education:
            df = df[df["Education"].isin(selected_education)]
        if selected_employment:
            df = df[df["EmploymentType"].isin(selected_employment)]

        risk_level = _risk_level_from_default_flag(df)
        total = len(df)
        high = int((risk_level == "HIGH").sum())
        medium = int((risk_level == "MEDIUM").sum())
        low = int((risk_level == "LOW").sum())
        alerts = int(df.get("Default", pd.Series(dtype=int)).sum())

        if total == 0:
            st.info("No loans match the selected filters.")
            return

    col1, col2, col3, col4, col5 = st.columns(5)
    with col1:
        st.markdown(kpi_card("Total Loans", f"{total:,}"), unsafe_allow_html=True)
    with col2:
        st.markdown(
            kpi_card("High Risk", f"{high:,}", RISK_COLORS["HIGH"]),
            unsafe_allow_html=True,
        )
    with col3:
        st.markdown(
            kpi_card("Medium Risk", f"{medium:,}", RISK_COLORS["MEDIUM"]),
            unsafe_allow_html=True,
        )
    with col4:
        st.markdown(
            kpi_card("Low Risk", f"{low:,}", RISK_COLORS["LOW"]),
            unsafe_allow_html=True,
        )
    with col5:
        st.markdown(kpi_card("Today's Alerts", f"{alerts:,}"), unsafe_allow_html=True)

    st.markdown("<br>", unsafe_allow_html=True)

    left, right = st.columns(2)

    with left:
        st.subheader("Risk Distribution")
        dist_df = pd.DataFrame(
            {"Risk Level": ["High", "Medium", "Low"], "Count": [high, medium, low]}
        )
        fig = px.pie(
            dist_df,
            names="Risk Level",
            values="Count",
            color="Risk Level",
            color_discrete_map={"High": RISK_COLORS["HIGH"], "Medium": RISK_COLORS["MEDIUM"], "Low": RISK_COLORS["LOW"]},
            hole=0.5,
        )
        fig.update_layout(margin=dict(t=10, b=10, l=10, r=10), showlegend=True)
        st.plotly_chart(fig, use_container_width=True)

    with right:
        st.subheader("Loans by Type")
        if df is not None and "LoanPurpose" in df.columns:
            type_counts = df["LoanPurpose"].value_counts().reset_index()
            type_counts.columns = ["Loan Type", "Count"]
        else:
            type_counts = pd.DataFrame(
                {
                    "Loan Type": ["Home", "Auto", "Business", "Education", "Other"],
                    "Count": [4200, 3100, 2400, 1600, 1200],
                }
            )
        fig2 = px.bar(type_counts, x="Loan Type", y="Count")
        fig2.update_layout(margin=dict(t=10, b=10, l=10, r=10))
        st.plotly_chart(fig2, use_container_width=True)

    st.subheader("Monthly Risk Trend")
    months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul"]
    trend_df = pd.DataFrame(
        {
            "Month": months,
            "Avg Risk Score": [0.42, 0.45, 0.41, 0.48, 0.52, 0.49, 0.46],
        }
    )
    fig3 = px.line(trend_df, x="Month", y="Avg Risk Score", markers=True)
    fig3.update_layout(margin=dict(t=10, b=10, l=10, r=10))
    st.plotly_chart(fig3, use_container_width=True)

    if df is not None:
        st.subheader("Loan Search")
        search = st.text_input("Search by Loan ID", key="dashboard_search")
        result_df = df
        if search and "LoanID" in df.columns:
            result_df = df[df["LoanID"].astype(str).str.contains(search, case=False, na=False)]
        st.dataframe(
            result_df.head(200)[[c for c in ["LoanID", "Age", "Income", "LoanAmount",
                                              "CreditScore", "LoanPurpose", "Default"]
                                  if c in result_df.columns]],
            use_container_width=True,
            height=300,
        )
