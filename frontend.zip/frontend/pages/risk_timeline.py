"""Page 7 - Risk Timeline"""

import streamlit as st
import pandas as pd
import plotly.express as px


def render():
    st.title("📈 Risk Timeline")
    st.caption("Monthly risk trend across the portfolio")

    # TODO: replace with a real time-series endpoint once available
    # (e.g. GET /risk-trend) — placeholder data shown for now.
    months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul"]
    trend_df = pd.DataFrame(
        {
            "Month": months,
            "High Risk %": [12, 13, 11, 15, 18, 16, 14],
            "Medium Risk %": [34, 35, 33, 36, 38, 37, 35],
            "Low Risk %": [54, 52, 56, 49, 44, 47, 51],
        }
    )

    melted = trend_df.melt(id_vars="Month", var_name="Risk Level", value_name="Percent")
    fig = px.line(
        melted,
        x="Month",
        y="Percent",
        color="Risk Level",
        markers=True,
        color_discrete_map={
            "High Risk %": "#e74c3c",
            "Medium Risk %": "#f39c12",
            "Low Risk %": "#2ecc71",
        },
    )
    fig.update_layout(margin=dict(t=10, b=10, l=10, r=10))
    st.plotly_chart(fig, use_container_width=True)

    st.dataframe(trend_df, use_container_width=True)
