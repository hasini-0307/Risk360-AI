"""Page 2 - Borrower Profile"""

import streamlit as st
from components.api import analyze, with_spinner
from components.data import find_borrower, build_analysis_payload, load_dataset
from components.styles import risk_badge


def render():
    st.title("👤 Borrower Profile")
    st.caption("Look up a borrower and run a full risk analysis")

    df = load_dataset()
    if df is None:
        st.error(
            "Dataset not found at `data/Loan_default_multimodal.csv`. "
            "Can't look up borrowers without it."
        )
        return

    loan_id = st.text_input(
        "Loan ID", value=st.session_state.get("customer_id", ""),
        placeholder="e.g. I38PQUQS96",
    )

    if not loan_id:
        st.info("Enter a Loan ID to look up this borrower.")
        with st.expander("Don't have one handy? Sample Loan IDs"):
            st.dataframe(df[["LoanID", "LoanPurpose", "Default"]].head(10), use_container_width=True)
        return

    st.session_state["customer_id"] = loan_id

    if st.button("Run analysis", type="primary"):
        row = find_borrower(loan_id)
        if row is None:
            st.error(f"No borrower found with Loan ID '{loan_id}'.")
            st.session_state["analysis_data"] = None
        else:
            payload = build_analysis_payload(row)
            data = with_spinner("Running full risk analysis...", analyze, payload)
            st.session_state["analysis_data"] = data
            st.session_state["borrower_row"] = row

    data = st.session_state.get("analysis_data")
    if not data:
        return

    row = st.session_state.get("borrower_row", {})
    cro = data.get("cro_decision", {})

    st.markdown("---")
    col1, col2 = st.columns([2, 1])

    with col1:
        st.subheader("Customer Details")
        st.write(f"**Loan ID:** {loan_id}")
        st.write(f"**Age:** {row.get('Age', 'N/A')}")
        st.write(f"**Income:** {row.get('Income', 'N/A'):,}" if row.get("Income") is not None else "**Income:** N/A")
        st.write(f"**Employment Type:** {row.get('EmploymentType', 'N/A')}")

        st.subheader("Loan Details")
        st.write(f"**Loan Type:** {row.get('LoanPurpose', 'N/A')}")
        st.write(f"**Loan Amount:** {row.get('LoanAmount', 'N/A')}")
        st.write(f"**Credit Score:** {row.get('CreditScore', 'N/A')}")
        st.write(f"**DTI Ratio:** {row.get('DTIRatio', 'N/A')}")

    with col2:
        st.subheader("Risk Summary")
        overall_risk = cro.get("overall_risk", "UNKNOWN")
        st.markdown(risk_badge(overall_risk), unsafe_allow_html=True)
        st.metric("Default Probability", f"{data.get('default_probability', 0):.0%}")
        st.metric("Model Confidence", f"{cro.get('confidence', 0):.0%}")
        st.write(f"**ML Prediction:** {'Will Default' if data.get('prediction') == 1 else 'Will Repay'}")
        st.write(f"**Approval Recommendation:** {cro.get('approval_recommendation', 'N/A')}")

    st.markdown("---")
    st.caption(
        "Jump to the Explainability, Similar Borrowers, or Recommendations "
        "pages from the sidebar — they'll use this same analysis."
    )
