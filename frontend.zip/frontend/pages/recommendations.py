"""Page 5 - Recommendations

NOTE: there is no standalone /recommendation endpoint on the backend.
Recommended actions come from the `cro_decision.recommended_actions`
field returned by POST /analyze (the Chief Risk Officer's output after
combining all specialist agents).
"""

import streamlit as st
from components.api import analyze, with_spinner
from components.data import find_borrower, build_analysis_payload
from components.styles import risk_badge

ICON_KEYWORDS = {
    "emi": "💳",
    "restructur": "🔄",
    "monitor": "🔎",
    "counsel": "🧭",
    "repayment": "💰",
    "review": "🔍",
    "collateral": "🏦",
}


def _icon_for(text: str) -> str:
    lower = str(text).lower()
    for kw, icon in ICON_KEYWORDS.items():
        if kw in lower:
            return icon
    return "✅"


def _get_analysis(loan_id: str, row: dict):
    cached = st.session_state.get("analysis_data")
    if cached and st.session_state.get("customer_id") == loan_id:
        return cached
    payload = build_analysis_payload(row)
    return with_spinner("Running full analysis...", analyze, payload)


def render():
    st.title("💡 Recommendations")
    st.caption("The Chief Risk Officer's recommended actions for this borrower")

    loan_id = st.text_input(
        "Loan ID", value=st.session_state.get("customer_id", ""), key="rec_loan_id"
    )

    if not loan_id:
        st.info("Enter a Loan ID to generate recommendations.")
        return

    row = find_borrower(loan_id)
    if row is None:
        st.error(f"No borrower found with Loan ID '{loan_id}'.")
        return

    if st.button("Generate recommendations", type="primary"):
        st.session_state["rec_analysis"] = _get_analysis(loan_id, row)

    data = st.session_state.get("rec_analysis")
    if not data:
        return

    cro = data.get("cro_decision", {})
    actions = cro.get("recommended_actions", [])

    col1, col2 = st.columns([1, 3])
    with col1:
        st.markdown(risk_badge(cro.get("overall_risk", "UNKNOWN")), unsafe_allow_html=True)
    with col2:
        st.write(f"**Approval recommendation:** {cro.get('approval_recommendation', 'N/A')}")

    if cro.get("executive_summary"):
        st.info(cro["executive_summary"])

    if not actions:
        st.warning("No recommended actions returned for this borrower.")
        return

    st.subheader("Recommended Actions")
    cols = st.columns(2)
    for i, action in enumerate(actions):
        with cols[i % 2]:
            st.markdown(
                f"""
                <div class="rec-card">
                    <h4>{_icon_for(action)} {action}</h4>
                </div>
                """,
                unsafe_allow_html=True,
            )

    if cro.get("top_risk_drivers"):
        with st.expander("Top risk drivers behind this decision"):
            for driver in cro["top_risk_drivers"]:
                st.write(f"- {driver}")

    if cro.get("conflicting_assessments"):
        with st.expander("Conflicting agent assessments"):
            for c in cro["conflicting_assessments"]:
                st.write(f"- {c}")
