# Risk360 AI — Frontend (Person 3)

Streamlit dashboard for the Risk360 loan-default risk platform. Talks to the
FastAPI backend (Person 2) for predictions, explanations, similar borrowers,
recommendations, and the AI Copilot (Person 1's LLM logic, exposed via
Person 2's `/copilot` endpoint).

## Setup

```bash
cd frontend
python -m venv venv && source venv/bin/activate   # or your preferred env tool
pip install -r requirements.txt
cp .env.example .env   # point RISK360_API_URL at the real backend
streamlit run app.py
```

## Structure

```
frontend/
├── app.py                     # entrypoint, sidebar nav, page routing
├── components/
│   ├── api.py                 # POST helpers for /predict /explain /similar
│   │                           #   /recommendation /copilot, with error handling
│   ├── config.py              # API_BASE_URL + endpoint map (env-configurable)
│   └── styles.py               # shared CSS, KPI cards, risk badges
├── pages/
│   ├── dashboard.py            # Page 1 – Executive Dashboard
│   ├── borrower_profile.py     # Page 2 – Borrower Profile
│   ├── explainability.py       # Page 3 – SHAP feature importance
│   ├── similar_borrowers.py    # Page 4 – Similar Borrowers
│   ├── recommendations.py      # Page 5 – Recommendation cards
│   ├── copilot.py              # Page 6 – AI Copilot chat
│   └── risk_timeline.py        # Page 7 – Monthly risk trend
├── assets/                     # logo / static files
└── requirements.txt
```

## API contract (verified against real backend source, not the original doc)

The original task-split doc's contract turned out not to match what was
actually built. **There is no customer_id lookup on the backend.** Every
endpoint takes the borrower's raw feature values directly, matching the
exact columns the CatBoost model was trained on (see
`components/config.py: MODEL_FEATURE_COLUMNS`). `components/data.py`
bridges "user picks a Loan ID in the UI" to "send the right payload".

| Endpoint | Request | Response |
|---|---|---|
| `POST /predict` | raw feature dict | `{prediction: 0\|1, default_probability: float}` |
| `POST /explain` | raw feature dict | `{top_features: [[feature, value], ...]}` (tuples, not `{feature, impact}` objects) |
| `POST /similar` | raw feature dict + `branch_notes`/`call_summary`/`verification_notes` | `{similar_borrowers: [{LoanID, Distance}, ...]}` |
| `POST /analyze` | same as above + `borrower_id`/`loan_id`/`loan_type` | everything at once — prediction, explanation, similar borrowers, and `cro_decision` (see below) |

There is **no** standalone `/recommendation` or `/copilot` route.
Recommendations and the Copilot's summary both come from
`cro_decision`, part of the `/analyze` response:

```json
{
  "overall_risk": "HIGH",
  "confidence": 0.87,
  "executive_summary": "...",
  "top_risk_drivers": ["...", "..."],
  "conflicting_assessments": [...],
  "recommended_actions": ["...", "..."],
  "approval_recommendation": "...",
  "processing_time_ms": 42,
  "metadata": {...}
}
```

**The Copilot page is not a real chat.** `executive_summary` is a
one-shot narrative generated per `/analyze` call, not an endpoint that
answers arbitrary questions. The page says this explicitly rather than
faking a chat experience. If a real Q&A endpoint gets built later, only
`pages/copilot.py` needs to change.

Most pages call `/analyze` once (via Borrower Profile) and reuse the
cached result across Explainability / Similar Borrowers / Recommendations
/ Copilot for the same Loan ID, to avoid re-running the whole pipeline
(4 agents + LLM call) on every page visit.

## Notes / TODO

- The Executive Dashboard's portfolio-wide KPIs currently read from a local
  CSV (`data/Loan_default_multimodal.csv`) as a stand-in for a bulk/portfolio
  endpoint. Swap `load_portfolio_data()` in `pages/dashboard.py` for a real
  API call once one exists.
- `pages/risk_timeline.py` uses placeholder monthly data until a time-series
  endpoint is available.
- Not yet done (per the original roadmap, still to wire up before the PR):
  loading indicators are in place via `with_spinner`, but search/filter,
  full responsive polish, and end-to-end testing against the live backend
  are still pending.

## Git workflow

Work only on `feature-frontend`. When ready:

```bash
git add .
git commit -m "Build out Risk360 frontend: all 7 pages + API integration"
git push origin feature-frontend
```

Then open a PR into `main` and notify Person 1 for review/merge.
