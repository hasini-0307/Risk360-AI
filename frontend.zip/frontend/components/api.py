"""
Reusable API helper functions for the real Risk360 backend endpoints.

IMPORTANT: unlike the original API-contract doc, none of these take a
customer_id. The backend has no lookup by ID — every call sends the
borrower's raw feature values directly (see components/data.py for how
those are built from a dataset row). There is also no standalone
/recommendation or /copilot route; that logic all lives inside the
/analyze response's `cro_decision` object.

Every function returns (data, error) so pages can render loading /
error states consistently instead of letting exceptions bubble up
into a raw Streamlit traceback.
"""

import requests
import streamlit as st
from components.config import ENDPOINTS, REQUEST_TIMEOUT


def _post(url: str, payload: dict):
    try:
        resp = requests.post(url, json=payload, timeout=REQUEST_TIMEOUT)
        resp.raise_for_status()
        return resp.json(), None
    except requests.exceptions.ConnectionError:
        return None, "Could not reach the backend. Is the API server running?"
    except requests.exceptions.Timeout:
        return None, "The backend took too long to respond."
    except requests.exceptions.HTTPError as e:
        return None, f"Backend returned an error: {e.response.status_code} - {e.response.text[:200]}"
    except Exception as e:  # noqa: BLE001
        return None, f"Unexpected error: {e}"


def get_prediction(payload: dict):
    """POST /predict -> {prediction: 0|1, default_probability: float}"""
    return _post(ENDPOINTS["predict"], payload)


def get_explanation(payload: dict):
    """POST /explain -> {top_features: [[feature, value], ...]}"""
    return _post(ENDPOINTS["explain"], payload)


def get_similar_borrowers(payload: dict):
    """POST /similar -> {similar_borrowers: [{LoanID, Distance}, ...]}"""
    return _post(ENDPOINTS["similar"], payload)


def analyze(payload: dict):
    """
    POST /analyze -> the full picture in one call:
    {
      prediction, default_probability,
      top_features: [[feature, value], ...],
      similar_borrowers: [{LoanID, Distance}, ...],
      cro_decision: {
        overall_risk, confidence, executive_summary,
        top_risk_drivers, conflicting_assessments,
        recommended_actions, approval_recommendation,
        processing_time_ms, metadata
      }
    }
    """
    return _post(ENDPOINTS["analyze"], payload)


def with_spinner(label: str, fn, *args, **kwargs):
    """Wrap any API call with a Streamlit spinner + inline error rendering."""
    with st.spinner(label):
        data, error = fn(*args, **kwargs)
    if error:
        st.error(error)
        return None
    return data
