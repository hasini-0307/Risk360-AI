"""
Central configuration for the Risk360 frontend.
Backend base URL is read from the RISK360_API_URL environment variable,
falling back to localhost:8000 for local dev.
"""

import os

API_BASE_URL = os.getenv("RISK360_API_URL", "http://localhost:8000")

ENDPOINTS = {
    "predict": f"{API_BASE_URL}/predict",
    "explain": f"{API_BASE_URL}/explain",
    "similar": f"{API_BASE_URL}/similar",
    "analyze": f"{API_BASE_URL}/analyze",
}

# Exact feature columns the CatBoost model was trained on. Anything sent to
# /predict, /explain, or /analyze must include these (extra keys are fine,
# missing ones will come through as None and break prediction).
MODEL_FEATURE_COLUMNS = [
    "Age", "Income", "LoanAmount", "CreditScore", "MonthsEmployed",
    "NumCreditLines", "InterestRate", "LoanTerm", "DTIRatio",
    "Education", "EmploymentType", "MaritalStatus", "HasMortgage",
    "HasDependents", "LoanPurpose", "HasCoSigner",
]

REQUEST_TIMEOUT = 15  # seconds

RISK_COLORS = {
    "HIGH": "#e74c3c",
    "MEDIUM": "#f39c12",
    "LOW": "#2ecc71",
}
