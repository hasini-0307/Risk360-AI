"""Shared CSS and small UI helpers used across all pages."""

import streamlit as st
from components.config import RISK_COLORS


CUSTOM_CSS = """
<style>
:root {
    --bg-primary: #0e1117;
    --bg-card: #1a1d24;
    --accent: #4f8bf9;
    --text-muted: #9aa0a6;
}

.kpi-card {
    background: var(--bg-card);
    border-radius: 12px;
    padding: 1.25rem 1.5rem;
    border: 1px solid rgba(255,255,255,0.06);
    text-align: left;
    transition: transform 0.15s ease, border-color 0.15s ease;
}
.kpi-card:hover {
    transform: translateY(-2px);
    border-color: rgba(79,139,249,0.4);
}
.kpi-card h3 {
    font-size: 0.85rem;
    color: var(--text-muted);
    margin: 0 0 0.35rem 0;
    font-weight: 500;
    text-transform: uppercase;
    letter-spacing: 0.04em;
}
.kpi-card .value {
    font-size: 1.9rem;
    font-weight: 700;
    margin: 0;
}

.rec-card {
    background: var(--bg-card);
    border-left: 4px solid var(--accent);
    border-radius: 8px;
    padding: 1rem 1.25rem;
    margin-bottom: 0.75rem;
    transition: box-shadow 0.15s ease, border-left-color 0.15s ease;
}
.rec-card:hover {
    box-shadow: 0 4px 14px rgba(0,0,0,0.25);
    border-left-color: #7badff;
}

@media (max-width: 768px) {
    .kpi-card .value { font-size: 1.4rem; }
    .kpi-card { padding: 1rem; }
}
.rec-card h4 {
    margin: 0 0 0.4rem 0;
}
.rec-card p {
    margin: 0;
    color: var(--text-muted);
}

.badge {
    display: inline-block;
    padding: 0.15rem 0.6rem;
    border-radius: 999px;
    font-size: 0.75rem;
    font-weight: 600;
}

section[data-testid="stSidebar"] {
    border-right: 1px solid rgba(255,255,255,0.06);
}
</style>
"""


def inject_custom_css():
    st.markdown(CUSTOM_CSS, unsafe_allow_html=True)


def risk_badge(risk_level: str) -> str:
    color = RISK_COLORS.get(str(risk_level).upper(), "#888")
    return (
        f'<span class="badge" style="background:{color}22;color:{color};">'
        f'{risk_level}</span>'
    )


def kpi_card(label: str, value, color: str = None) -> str:
    style = f'style="color:{color};"' if color else ""
    return f"""
    <div class="kpi-card">
        <h3>{label}</h3>
        <p class="value" {style}>{value}</p>
    </div>
    """
