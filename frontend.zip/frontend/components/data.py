"""
Loads the local borrower dataset and builds request payloads that match
what backend/ml/predict.py and ai_engine's AIRequest actually expect.

There is no customer_id lookup on the backend — /predict, /explain,
/similar, and /analyze all take the borrower's raw feature values
directly. This module is what bridges "pick a Loan ID in the UI" to
"send the right dict to the API".
"""

import streamlit as st
import pandas as pd

DATA_PATH = "data/Loan_default_multimodal.csv"

# Columns that exist in the dataset but must NOT be sent to the model
# (they're either the label or identifiers/text fields the model wasn't
# trained on directly).
NON_FEATURE_COLUMNS = ["LoanID", "Default"]


@st.cache_data
def load_dataset():
    try:
        return pd.read_csv(DATA_PATH)
    except FileNotFoundError:
        return None


def find_borrower(loan_id: str):
    """Returns the matching row as a dict, or None if not found."""
    df = load_dataset()
    if df is None:
        return None
    match = df[df["LoanID"].astype(str) == str(loan_id)]
    if match.empty:
        return None
    return match.iloc[0].to_dict()


def build_analysis_payload(borrower_row: dict) -> dict:
    """
    Builds the payload for /predict, /explain, /similar, /analyze from a
    borrower's raw dataset row. Includes model features PLUS the text
    fields (branch_notes, call_summary, verification_notes) that /similar
    and /analyze use for retrieval, PLUS the identifiers /analyze uses to
    build its AIRequest (borrower_id, loan_id, loan_type).
    """
    payload = {k: v for k, v in borrower_row.items() if k not in NON_FEATURE_COLUMNS}
    payload["borrower_id"] = borrower_row.get("LoanID", "UNKNOWN")
    payload["loan_id"] = borrower_row.get("LoanID", "UNKNOWN")
    payload["loan_type"] = borrower_row.get("LoanPurpose", "Unknown")
    return payload


def lookup_similar_borrower_details(loan_id: str):
    """
    /similar and /analyze only return {LoanID, Distance} for similar
    borrowers. Since we have the full dataset locally, enrich that with
    the actual outcome and branch notes for display.
    """
    row = find_borrower(loan_id)
    if row is None:
        return {"outcome": "Unknown", "reason": "Not found in local dataset"}
    return {
        "outcome": "Defaulted" if row.get("Default") == 1 else "Repaid",
        "reason": row.get("branch_notes", "—"),
    }
