"""
Risk360 AI — Frontend entrypoint (Person 3 / feature-frontend)

Wide layout, dark theme, sidebar navigation via streamlit-option-menu.
Run with: streamlit run app.py
"""

import streamlit as st
from streamlit_option_menu import option_menu

from components.styles import inject_custom_css
from pages import (
    dashboard,
    borrower_profile,
    explainability,
    similar_borrowers,
    recommendations,
    copilot,
    risk_timeline,
)

st.set_page_config(
    page_title="Risk360 AI",
    page_icon="🛡️",
    layout="wide",
    initial_sidebar_state="expanded",
)

inject_custom_css()

PAGES = {
    "Executive Dashboard": (dashboard, "speedometer2"),
    "Borrower Profile": (borrower_profile, "person-badge"),
    "Explainability": (explainability, "search"),
    "Similar Borrowers": (similar_borrowers, "people"),
    "Recommendations": (recommendations, "lightbulb"),
    "AI Copilot": (copilot, "robot"),
    "Risk Timeline": (risk_timeline, "graph-up"),
}

with st.sidebar:
    st.markdown("## 🛡️ Risk360 AI")
    st.caption("Loan Default Intelligence Platform")
    st.markdown("---")

    selected = option_menu(
        menu_title=None,
        options=list(PAGES.keys()),
        icons=[icon for _, icon in PAGES.values()],
        default_index=0,
        styles={
            "container": {"padding": "0", "background-color": "transparent"},
            "icon": {"font-size": "16px"},
            "nav-link": {"font-size": "14px", "text-align": "left", "margin": "2px 0"},
            "nav-link-selected": {"background-color": "#4f8bf9"},
        },
    )

    st.markdown("---")
    st.caption("Connected backend:")
    from components.config import API_BASE_URL

    st.code(API_BASE_URL, language=None)

page_module, _ = PAGES[selected]
page_module.render()
