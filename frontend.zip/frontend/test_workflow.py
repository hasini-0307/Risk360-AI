"""
Integration smoke test for the real Risk360 workflow.

Run this AFTER pointing .env / RISK360_API_URL at the real running backend,
and BEFORE opening the PR. Unlike the original API-contract doc, there's no
customer_id lookup — this pulls a real row out of the local dataset and
sends its actual feature values, matching what backend/ml/predict.py expects.

Usage:
    python test_workflow.py [loan_id]
"""

import sys
from components.api import get_prediction, get_explanation, get_similar_borrowers, analyze
from components.data import find_borrower, build_analysis_payload, load_dataset

DEFAULT_LOAN_ID = "I38PQUQS96"


def check(name, fn, payload):
    data, error = fn(payload)
    if error:
        print(f"FAIL {name}: {error}")
        return False
    print(f"OK   {name}: {data}")
    return True


def main():
    loan_id = sys.argv[1] if len(sys.argv) > 1 else DEFAULT_LOAN_ID

    df = load_dataset()
    if df is None:
        print("Could not find data/Loan_default_multimodal.csv - can't build a test payload.")
        sys.exit(1)

    row = find_borrower(loan_id)
    if row is None:
        print(f"Loan ID '{loan_id}' not found in dataset. Try one of:")
        print(df["LoanID"].head(5).tolist())
        sys.exit(1)

    payload = build_analysis_payload(row)
    print(f"Testing Risk360 workflow for Loan ID={loan_id}\n")

    results = [
        check("POST /predict", get_prediction, payload),
        check("POST /explain", get_explanation, payload),
        check("POST /similar", get_similar_borrowers, payload),
        check("POST /analyze", analyze, payload),
    ]

    print("\n" + "=" * 50)
    if all(results):
        print("All endpoints responded successfully. Ready for PR.")
        sys.exit(0)
    else:
        print("Some endpoints failed - fix before opening the PR.")
        sys.exit(1)


if __name__ == "__main__":
    main()
