"""Shared CSS and small UI helpers used across all pages.

Formal banking aesthetic: navy + brass on parchment, serif headings,
monospace figures, engraved sidebar texture, wax-seal risk medallion.
"""

import streamlit as st

RISK_COLORS = {
    "HIGH": {"bg": "#F3E3E1", "border": "#D9BDB8", "text": "#7A2E2E", "dot": "#7A2E2E"},
    "MEDIUM": {"bg": "#F2ECDD", "border": "#DDCD9F", "text": "#8A6D1F", "dot": "#8A6D1F"},
    "LOW": {"bg": "#E4EBE1", "border": "#C9D8C3", "text": "#2F5233", "dot": "#2F5233"},
    "UNKNOWN": {"bg": "#EDEBE4", "border": "#D8D3C4", "text": "#5A5646", "dot": "#8A8570"},
}

CUSTOM_CSS = """
<style>
@import url('https://fonts.googleapis.com/css2?family=Source+Serif+4:wght@400;500;600&family=Inter:wght@400;500;600&family=IBM+Plex+Mono:wght@400;500&display=swap');

:root {
    --navy: #14315C;
    --navy-deep: #0A1B32;
    --brass: #B08D57;
    --brass-light: #D4B77A;
    --parchment: #FBFAF6;
    --ink: #5A5646;
    --ink-muted: #9C9680;
    --hairline: #E4DFCF;
}

.stApp {
    background: var(--parchment);
}

h1, h2, h3 {
    font-family: 'Source Serif 4', Georgia, serif !important;
    color: var(--navy) !important;
    font-weight: 500 !important;
}

h1 {
    border-bottom: 2px double var(--navy);
    padding-bottom: 10px;
    margin-bottom: 4px !important;
}

p, div, span, label {
    font-family: 'Inter', -apple-system, sans-serif;
}

[data-testid="stCaptionContainer"] {
    font-size: 11px !important;
    letter-spacing: 0.07em;
    text-transform: uppercase;
    color: var(--ink-muted) !important;
}

/* -------- Sidebar: engraved letterhead -------- */
section[data-testid="stSidebar"] > div:first-child {
    background:
        radial-gradient(circle at 15% 10%, rgba(212,183,122,0.10) 0, transparent 45%),
        repeating-radial-gradient(circle at 50% 50%, rgba(212,183,122,0.05) 0px, transparent 2px, transparent 30px),
        linear-gradient(165deg, var(--navy) 0%, var(--navy-deep) 100%);
    border-right: 1px solid var(--brass);
}

section[data-testid="stSidebar"] * {
    color: #C9D2E0;
}

section[data-testid="stSidebar"] h1,
section[data-testid="stSidebar"] h2,
section[data-testid="stSidebar"] h3 {
    color: #F5F2E9 !important;
    border-bottom: none;
}

/* -------- Cards: ledger style, rectangular -------- */
.kpi-card {
    background: #FFFFFF;
    border: 1px solid var(--hairline);
    border-radius: 2px;
    padding: 13px 15px;
    box-shadow: 0 1px 3px rgba(20,49,92,0.06);
}
.kpi-card h3 {
    font-family: 'Inter', sans-serif !important;
    font-size: 10.5px !important;
    color: var(--ink-muted) !important;
    margin: 0 0 4px 0 !important;
    font-weight: 500 !important;
    text-transform: uppercase;
    letter-spacing: 0.06em;
    border-bottom: none !important;
    padding-bottom: 0 !important;
}
.kpi-card .value {
    font-family: 'IBM Plex Mono', monospace;
    font-size: 22px;
    font-weight: 500;
    margin: 0;
    color: var(--navy);
}

.rec-card {
    background: #FFFFFF;
    border: 1px solid var(--hairline);
    border-left: 3px solid var(--brass);
    border-radius: 0 2px 2px 0;
    padding: 12px 16px;
    margin-bottom: 10px;
}
.rec-card h4 {
    font-family: 'Source Serif 4', Georgia, serif;
    font-size: 15px;
    font-weight: 500;
    margin: 0;
    color: var(--navy);
}

/* -------- Risk badge: rectangular with status dot -------- */
.badge {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    padding: 4px 12px;
    border-radius: 2px;
    font-size: 11px;
    font-weight: 500;
    letter-spacing: 0.05em;
    text-transform: uppercase;
    font-family: 'Inter', sans-serif;
}
.badge .dot {
    width: 6px;
    height: 6px;
    border-radius: 50%;
    display: inline-block;
}

/* -------- Buttons -------- */
.stButton > button {
    font-family: 'Inter', sans-serif;
    border-radius: 2px !important;
    border: 1px solid var(--navy) !important;
    color: var(--navy) !important;
    background: #FFFFFF !important;
}
.stButton > button:hover {
    background: var(--navy) !important;
    color: #F5F2E9 !important;
}
.stButton > button[kind="primary"] {
    background: var(--navy) !important;
    color: #F5F2E9 !important;
    border: 1px solid var(--brass) !important;
}
.stButton > button[kind="primary"]:hover {
    background: var(--navy-deep) !important;
}

/* -------- Text inputs: monospace for reference numbers -------- */
input {
    font-family: 'IBM Plex Mono', monospace !important;
}

/* -------- Tables -------- */
[data-testid="stDataFrame"] {
    border: 1px solid var(--hairline) !important;
    border-radius: 2px !important;
}
</style>
"""


def inject_custom_css():
    st.markdown(CUSTOM_CSS, unsafe_allow_html=True)


def risk_badge(risk_level: str) -> str:
    level = str(risk_level).upper()
    c = RISK_COLORS.get(level, RISK_COLORS["UNKNOWN"])
    return (
        f'<span class="badge" style="background:{c["bg"]};color:{c["text"]};'
        f'border:1px solid {c["border"]};">'
        f'<span class="dot" style="background:{c["dot"]};"></span>{level} RISK</span>'
    )


def risk_medallion(risk_level: str, subtitle: str = "") -> str:
    """The signature wax-seal medallion, reserved for the Borrower Profile
    page's primary risk summary — used sparingly by design."""
    level = str(risk_level).upper()
    c = RISK_COLORS.get(level, RISK_COLORS["UNKNOWN"])
    return f"""
    <div style="display:flex; align-items:center; gap:14px; margin-bottom:14px;">
        <div style="width:56px; height:56px; border-radius:50%;
                    background:radial-gradient(circle at 35% 30%, {c['dot']}, {c['text']});
                    display:flex; align-items:center; justify-content:center;
                    box-shadow:0 2px 5px rgba(20,49,92,0.25); flex-shrink:0;">
            <div style="width:45px; height:45px; border-radius:50%;
                        border:1.5px dashed rgba(255,255,255,0.55);
                        display:flex; align-items:center; justify-content:center;">
                <span style="font-family:'Source Serif 4',Georgia,serif; font-size:9.5px;
                            color:#F5F2E9; text-align:center; line-height:1.15; letter-spacing:0.03em;">
                    {level}<br/>RISK
                </span>
            </div>
        </div>
        <div style="font-family:'Inter',sans-serif; font-size:12px; color:var(--ink); line-height:1.4;">
            {subtitle}
        </div>
    </div>
    """


def kpi_card(label: str, value, color: str = None) -> str:
    style = f'style="color:{color};"' if color else ""
    return f"""
    <div class="kpi-card">
        <h3>{label}</h3>
        <p class="value" {style}>{value}</p>
    </div>
    """
