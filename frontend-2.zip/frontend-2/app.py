"""
Risk360 AI - Frontend entrypoint (Person 3 / feature-frontend)

Formal banking aesthetic: navy/brass letterhead sidebar, parchment
content area, serif headings, monospace figures.
Run with: streamlit run app.py
"""

import streamlit as st
from streamlit_option_menu import option_menu

from components.styles import inject_custom_css
from pages import (
    dashboard,
    borrower_profile,
    explainability,
    similar_borrowers,
    recommendations,
    copilot,
    risk_timeline,
)

st.set_page_config(
    page_title="Risk360 AI",
    page_icon="\U0001F6E1\uFE0F",
    layout="wide",
    initial_sidebar_state="expanded",
)

inject_custom_css()

PAGES = {
    "Executive dashboard": (dashboard, "speedometer2"),
    "Borrower profile": (borrower_profile, "person-badge"),
    "Explainability": (explainability, "search"),
    "Similar borrowers": (similar_borrowers, "people"),
    "Recommendations": (recommendations, "lightbulb"),
    "AI copilot": (copilot, "robot"),
    "Risk timeline": (risk_timeline, "graph-up"),
}

with st.sidebar:
    st.markdown(
        """
        <div style="display:flex; align-items:center; gap:9px; margin-bottom:2px;">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" aria-hidden="true">
                <path d="M12 2L3 6v6c0 5 3.8 8.7 9 10 5.2-1.3 9-5 9-10V6l-9-4z"
                      fill="none" stroke="#D4B77A" stroke-width="1.3"/>
                <path d="M8.5 12.5l2.3 2.3L16 9.8" stroke="#D4B77A" stroke-width="1.3"
                      stroke-linecap="round" stroke-linejoin="round"/>
            </svg>
            <span style="font-family:'Source Serif 4',Georgia,serif; font-size:18px;
                        letter-spacing:0.05em; color:#F5F2E9;">RISK360</span>
        </div>
        <div style="font-family:'Inter',sans-serif; font-size:9px; letter-spacing:0.18em;
                    color:#D4B77A; text-transform:uppercase; margin:0 0 1.25rem 33px;">
            Credit risk intelligence
        </div>
        <div style="height:1px; background:linear-gradient(90deg,transparent,
                    rgba(212,183,122,0.8),transparent); margin-bottom:1rem;"></div>
        """,
        unsafe_allow_html=True,
    )

    selected = option_menu(
        menu_title=None,
        options=list(PAGES.keys()),
        icons=[icon for _, icon in PAGES.values()],
        default_index=0,
        styles={
            "container": {"padding": "0", "background-color": "transparent"},
            "icon": {"font-size": "15px", "color": "#9FADC4"},
            "nav-link": {
                "font-size": "12.5px",
                "font-family": "Inter, sans-serif",
                "text-align": "left",
                "margin": "1px 0",
                "color": "#9FADC4",
                "--hover-color": "rgba(212,183,122,0.10)",
            },
            "nav-link-selected": {
                "background-color": "rgba(212,183,122,0.16)",
                "color": "#F5F2E9",
                "font-weight": "500",
                "border-left": "2px solid #D4B77A",
            },
        },
    )

    st.markdown(
        """
        <div style="height:1px; background:var(--hairline); margin:1.25rem 0 0.75rem;
                    opacity:0.3;"></div>
        <div style="font-family:'Inter',sans-serif; font-size:9.5px; color:#8592A8;
                    text-transform:uppercase; letter-spacing:0.06em;">Connected backend</div>
        """,
        unsafe_allow_html=True,
    )
    from components.config import API_BASE_URL

    st.code(API_BASE_URL, language=None)

page_module, _ = PAGES[selected]
page_module.render()
